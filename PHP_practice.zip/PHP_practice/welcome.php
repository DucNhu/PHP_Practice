
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css"> 
    <style>
        .container {
            width: 50%;
            margin: auto;
            padding: 15px
        }

        body {
             background: #a8ff78;  /* fallback for old browsers */
            background: -webkit-linear-gradient(to right, #78ffd6, #a8ff78);  /* Chrome 10-25, Safari 5.1-6 */
            background: linear-gradient(to right, #78ffd6, #a8ff78); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
        }
        h1 {
            color: white;
            text-align: center;
            font-size : 4em;
            text-shadow: 0px 0px 10px green;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="box">
            <h1>
                <?php echo "Wellcome </br> ".$_COOKIE['fullname'];?>
            </h1>
        </div>
    </div>
</body>
</html>